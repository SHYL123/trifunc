%因弧度和角度可相互转化，因此本test中sin与cos仅针对弧度进行测试。
%调用SinTest(n)函数，可以自动生成n个随机数进行n次测试，并计算相应误差，输出最大和最小的误差。
function y=SinTest(num)%num为想测试的次数
    min = 0;
    max = 0;
    arr=[];%可拓展
    for i = 1:num
    randomNum = randi(10000)/10000;%随机生成一个0~1 4位小数的数
    angle = 2*pi*randomNum;
    ans1 = sin(angle);%此处sin为matlab中的算法
    ans2 = MySin(angle);%此处MySin为本项目中的算法
    diff = ans2 - ans1;
    arr(i) = diff;
    if (diff>max)
        max = diff;
    end
    if(diff<min)
        min = diff;
    end
    end
    disp(['最小误差为',num2str(min)]);
    disp(['最大误差为',num2str(min)]);
end