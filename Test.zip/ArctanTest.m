%调用ArctanTest(n)函数，可以自动生成n个随机数进行n次测试，并计算相应误差，输出最大和最小的误差。
function y=ArctanTest(num)%num为想测试的次数
    min = 0;
    max = 0;
    arr=[];%可拓展
    for i = 1:num
    randomNum = (randi(200)-100)/101;%随机生成一个(-1,1)之间的数
    ans1 = atan(randomNum);%此处atan为matlab中的算法
    ans2 = MyArctan(randomNum)*pi/180;%此处MyArctan为本项目中的算法
    diff = ans2 - ans1;
    arr(i) = diff;
    if (diff>max)
        max = diff;
    end
    if(diff<min)
        min = diff;
    end
    end
    disp(['最小误差为',num2str(min)]);
    disp(['最大误差为',num2str(min)]);
end